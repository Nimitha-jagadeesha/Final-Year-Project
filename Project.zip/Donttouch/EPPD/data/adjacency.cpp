#include <bits/stdc++.h>

using namespace std;
int main()
{
    ifstream fin("fb.txt");
    ofstream fout("fbedges.txt");
    long int a[4039][4039]={0};
     for(int i=0;i<88234;i++)
     {
        int m,n;
        fin>>m>>n;
        cout<<m<<" "<<n<<endl;
        //a[m][n]=1;
     }
    // for(int i=0;i<4039;i++)
     {
         //for(int j=0;j<4039;j++)
            //cout<<a[i][j]<<" ";
         //cout<<endl;
     }
     return 0;
}


