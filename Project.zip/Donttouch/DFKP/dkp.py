from math import *


def nCr(n, r):
    f = factorial
    return f(n) / f(r) / f(n-r)


n = 100
m = 10
edges = []
file1 = open("data/fbedges.txt")
for i in range(500):
    edges.append(file1.readline().split(" "))
#     edges[i].remove("\n")
    edges[i] = list(map(int, edges[i]))
# print(edges)
nn=500
N = [[] for i in range(n)]
for i in range(n):
    for j in range(n):
        if edges[i][j] == 1 and i != j:
            N[i].append(j)
# print(N)

# file1 = open("FbInitial.edges", "w")

# for i in range(len(N)):
#     for j in range(len(N[i])):
#         file1.write(str(i)+" "+str(j)+"\n")
# file1.close()

privacy = []
file1 = open("data/fbprivacy.txt")
for i in range(n):
    privacy.append(file1.readline().split(" "))
    privacy[i] = privacy[i][0:-1]
    privacy[i] = list(map(float, privacy[i]))
# print(privacy)

P = [[] for i in range(n)]
for i in range(n):
    for j in range(n):
        if edges[i][j] == 1 and i != j:
            P[i].append(privacy[i][j])
# print(P)


secrets = []
file1 = open("data/fbsecrets.txt")
for i in range(n):
    secrets.append(file1.readline().split(" "))
#     secrets[i].remove("\n")
    secrets[i] = list(map(int, secrets[i]))
# print(secrets)

S = [[] for i in range(n)]
for i in range(n):
    for j in range(m):
        if secrets[i][j] == 1:
            S[i].append(j)
# print(S)


thresholdlist = []
file1 = open("data/fbthershold.txt")
for i in range(n):
    thresholdlist.append(file1.readline().split(" "))
    thresholdlist[i] = thresholdlist[i][0:-1]
    thresholdlist[i] = list(map(float, thresholdlist[i]))
# print(thresholdlist)

Q = [[] for i in range(n)]
for i in range(n):
    for j in range(m):
        if secrets[i][j] == 1:
            Q[i].append(thresholdlist[i][j])
            if(Q[i][-1] == 0):
                Q[i][-1] = 0.1
# print(Q)

Sel = set()
Pmax = 0
l = [i for i in range(n)]
for xx in range(n):
    Rmax = -1
    s = -1
    Isel = 0  # to be checked
    for i in l:
        for j in range(0, len(N[i])):
            Ii = 0
            Ij = 0
            Ii = log(1/(nCr(n-1, len(N[i]))))
            Ij = log(1/(nCr(n-1, len(N[N[i][j]]))))
            R = P[i][j]/(Ii+Ij)
            if R > Rmax:
                s = N[i][j]
                R = Rmax
                Isel = Ij

        flag = True
        for j in range(0, len(Q[s])):
            if Isel > log(Q[s][j]):
                flag = False
        if flag:
            Sel.add(s)
            Pmax += sum(P[s])

print(Pmax)
OutputList = [[] for i in range(n)]
Visited = [0 for i in range(n)]
Sel = list(Sel)
for i in Sel:
    Visited[i] = 1
    for j in N[i]:
        if j not in Sel:
            Visited[j] = 1

for i in range(n):
    if Visited[i] == 1:
        OutputList[i] = N[i]

file1 = open("Fboutput.edges", "w")

for i in range(len(OutputList)):
    for j in range(len(OutputList[i])):
        file1.write(str(i)+" "+str(j)+"\n")
# file1.close()
l=[100,200,300,400]
for i in range(len(OutputList)):
    for j in range(len(OutputList[i])):
        file1.write(str(i)+" "+str(j)+"\n")
    
        for k in (l):
            file1.write(str(i+k)+" "+str(j)+"\n")
    for j in range(len(OutputList[i])):
        for k in l:
            file1.write(str(i)+" "+str(j+k)+"\n")
file1.close()

