n = 500
m = 10
edges = []
file1 = open("data/fbedges.txt")
for i in range(500):
    edges.append(file1.readline().split(" "))
#     edges[i].remove("\n")
    edges[i] = list(map(int, edges[i]))
# print(edges)
nn=500
N = [[] for i in range(n)]
for i in range(n):
    for j in range(n):
        if edges[i][j] == 1 and i != j:
            N[i].append(j)


file1 = open("FbInitial.edges", "w")

for i in range(len(N)):
    for j in range(len(N[i])):
        file1.write(str(i)+" "+str(j)+"\n")
file1.close()